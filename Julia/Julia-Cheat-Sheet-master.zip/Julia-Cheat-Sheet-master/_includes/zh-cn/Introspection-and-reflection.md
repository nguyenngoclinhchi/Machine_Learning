
| -------------- | --------------------- |
| 类型           | `typeof(name)`        |
| 类型检查        | `isa(name, TypeName)` |
| 列出子类型      | `subtypes(TypeName)`  |
| 列出超类型      | `supertype(TypeName)` |
| 函数方法        | `methods(func)`       |
| 即时编译的字节码 | `code_llvm(expr)`     |
| 汇编代码        | `code_native(expr)`   |