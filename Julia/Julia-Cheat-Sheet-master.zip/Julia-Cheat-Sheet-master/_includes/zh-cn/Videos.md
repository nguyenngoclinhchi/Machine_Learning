- [科学计算新尝试——Julia语言入门教程](https://www.bilibili.com/video/av28178443/) by [Roger](http://discourse.juliacn.com/u/roger/summary)  


## YouTube 英文资源

- [第五届 JuliaCon 年会 2018](https://www.youtube.com/playlist?list=PLP8iPy9hna6Qsq5_-zrg0NTwqDSDYtfQB)
- [第四届 JuliaCon 年会 2017 (Berkeley)](https://www.youtube.com/playlist?list=PLP8iPy9hna6QpP6vqZs408etJVECPKIev)
- [第三届 JuliaCon 年会 2016](https://www.youtube.com/playlist?list=PLP8iPy9hna6SQPwZUDtAM59-wPzCPyD_S)
- [Julia 入门](https://www.youtube.com/watch?v=pHQdSmySQ_w&list=UU6LD83Gx-mFVq9y33w0YEug)
  by [Leah Hanson](https://twitter.com/astrieanna)
- [Julia 简介](https://youtu.be/8mZRIRHAZfo) by
  [Huda Nassar](https://twitter.com/nassarhuda)
- [给 Python 统计学家的 Julia 简介](https://youtu.be/Cj6bjqS5otM) by [John Pearson](https://twitter.com/jmxpearson)
