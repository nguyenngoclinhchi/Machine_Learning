## 在线 IJulia 笔记本
- [JuliaBox](https://www.juliabox.com) 
- [Jupyter](https://try.jupyter.org) 


## 文本编辑器
- [Juno](http://junolab.org) 
- [Emacs](https://www.gnu.org/software/emacs) \ [Julia
  模式](https://www.emacswiki.org/emacs/Julia) 
- [vim](https://www.vim.org) \ [Julia
  模式](https://github.com/JuliaLang/julia-vim) 
- [VS Code
  插件](https://marketplace.visualstudio.com/items?itemName=julialang.language-julia)

