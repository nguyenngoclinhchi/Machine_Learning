- [Julia 中文文档](http://docs.juliacn.com/latest/)
- [Julia 中文社区](http://discourse.juliacn.com/)   


## 英文资源

- [Julia 官方文档](https://docs.julialang.org/en/latest)
- [学习 Julia 的在线资源](https://julialang.org/learning)
- [Julia 之月](https://github.com/DataWookie/MonthOfJulia)
- [社区准则](https://julialang.org/community/standards) 
- [Julia: 数值计算的新尝试](https://arxiv.org/pdf/1411.1607v4.pdf) (pdf)
- [Julia: 为科学计算而生的快速动态语言](https://arxiv.org/pdf/1209.5145v1.pdf) (pdf)
