- [The 5th annual JuliaCon 2018](https://www.youtube.com/playlist?list=PLP8iPy9hna6Qsq5_-zrg0NTwqDSDYtfQB)
- [The 4th annual JuliaCon 2017 (Berkeley)](https://www.youtube.com/playlist?list=PLP8iPy9hna6QpP6vqZs408etJVECPKIev)
- [The 3rd annual JuliaCon 2016](https://www.youtube.com/playlist?list=PLP8iPy9hna6SQPwZUDtAM59-wPzCPyD_S)
- [Getting Started with Julia](https://www.youtube.com/watch?v=pHQdSmySQ_w&list=UU6LD83Gx-mFVq9y33w0YEug) :
  [Leah Hanson](https://twitter.com/astrieanna) さん
- [Intro to Julia](https://youtu.be/8mZRIRHAZfo) :
  [Huda Nassar](https://twitter.com/nassarhuda) さん
- [Introduction to Julia for Pythonistas](https://youtu.be/Cj6bjqS5otM) by [John Pearson](https://twitter.com/jmxpearson)
