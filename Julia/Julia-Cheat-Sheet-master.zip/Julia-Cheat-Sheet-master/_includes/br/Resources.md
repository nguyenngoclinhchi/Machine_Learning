- [Official documentation](https://docs.julialang.org/en/latest) .
- [Learning Julia](https://julialang.org/learning) page.
- [Month of Julia](https://github.com/DataWookie/MonthOfJulia)
- [Community standards](https://julialang.org/community/standards) .
- [Julia: A fresh approach to numerical
  computing](https://arxiv.org/pdf/1411.1607v4.pdf) (pdf)
- [Julia: A Fast Dynamic Language for Technical
  Computing](https://arxiv.org/pdf/1209.5145v1.pdf) (pdf)
