|                               |                                                                                             |
| ----------------------------- | ------------------------------------------------------------------------------------------- |
| Atribuição                    | `answer = 42`<br>`x, y, z = 1, [1:10; ], "A string"`<br>`x, y = y, x # swap x and y`        |
| Declaração de constante       | `const DATE_OF_BIRTH = 2012`                                                                |
| Comentário de final de linha  | `i = 1 # This is a comment`                                                                 |
| Comentário deliminitado       | `#= This is another comment =#`                                                             |
| Encadeamento                  | `x = y = z = 1  # right-to-left`<br>`0 < x < 3          # true`<br>`5 < x != y < 5 # false` |
| Definição de Função           | `function add_one(i)`<br>`    return i + 1`<br>`end`                                        |
| Inserir simbolos LaTex        | `\delta` + [Tab]                                                                            |
