|                      |                                                       |
| -------------------- | ----------------------------------------------------- |
| Assignment | `answer = 42`<br>`x, y, z = 1, [1:10; ], "A string"`<br>`x, y = y, x # swap x and y` |
| Constant declaration | `const DATE_OF_BIRTH = 2012`                          |
| End-of-line comment  | `i = 1 # This is a comment`                           |
| Delimited comment    | `#= This is another comment =#`                       |
| Chaining | `x = y = z = 1  # right-to-left`<br>`0 < x < 3      # true`<br>`5 < x != y < 5 # false` |
| Function definition  | `function add_one(i)`<br>`    return i + 1`<br>`end`  |
| Insert LaTeX symbols | `\delta` + [Tab]                                      |
