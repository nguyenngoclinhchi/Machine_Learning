- [Juno](https://junolab.org) (editor)
- [JuliaBox](https://www.juliabox.com) (online IJulia notebook)
- [Jupyter](https://try.jupyter.org) (online IJulia notebook)
- [Emacs](https://www.gnu.org/software/emacs) [Julia
  mode](https://www.emacswiki.org/emacs/Julia) (editor)
- [vim](https://www.vim.org) [Julia
  mode](https://github.com/JuliaLang/julia-vim) (editor)
- [VS Code
  extension](https://marketplace.visualstudio.com/items?itemName=julialang.language-julia)
  (editor)
